package com.aios.sgrs.security;

public enum TokenType { ACCESS, REFRESH }